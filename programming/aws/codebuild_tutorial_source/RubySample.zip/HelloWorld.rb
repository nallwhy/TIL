class HelloWorld
  def say_hello()
    return 'Hello, world!'
  end
end